// DriestarCrime Shop — eenvoudige Google Sheets API
// Vul hieronder je eigen waarden in.
const SPREADSHEET_ID = "VUL_HIER_JE_GOOGLE_SHEET_ID_IN";
const GOOGLE_CLIENT_ID = "VUL_HIER_JE_GOOGLE_OAUTH_CLIENT_ID_IN";
const SHEET_NAME = "Ads";

function setup() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  if (!ss.getSheetByName(SHEET_NAME)) {
    const sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(["id","createdAt","title","price","category","description","sellerName","sellerEmail","photo"]);
  }
}
function doGet() {
  const sh = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(SHEET_NAME);
  if (!sh || sh.getLastRow() < 2) return json({ads:[]});
  const rows = sh.getDataRange().getValues().slice(1);
  const ads = rows.reverse().map(r => ({id:r[0],createdAt:r[1],title:r[2],price:r[3],category:r[4],description:r[5],sellerName:r[6],sellerEmail:r[7],photo:r[8]}));
  return json({ads:ads});
}
function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || "{}");
    if (body.action !== "create" || !body.ad) throw new Error("Ongeldige aanvraag");
    const claims = verifyGoogleToken(body.credential);
    const ad = body.ad;
    if (!ad.title || !ad.description || !(Number(ad.price) >= 0)) throw new Error("Controleer de advertentiegegevens");
    let photo = "";
    if (ad.photo && String(ad.photo).startsWith("data:image/")) {
      const match = String(ad.photo).match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
      if (!match) throw new Error("Ongeldige afbeelding");
      const bytes = Utilities.base64Decode(match[2]);
      if (bytes.length > 1500000) throw new Error("Afbeelding is te groot");
      const blob = Utilities.newBlob(bytes, match[1], "dcs-" + Date.now());
      const file = DriveApp.createFile(blob);
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      photo = "https://drive.google.com/uc?export=view&id=" + file.getId();
    }
    const sh = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(SHEET_NAME);
    sh.appendRow([Utilities.getUuid(),new Date(),String(ad.title).slice(0,70),Number(ad.price),String(ad.category).slice(0,40),String(ad.description).slice(0,1200),claims.name,claims.email,photo]);
    return json({ok:true});
  } catch(err) { return json({ok:false,error:String(err.message || err)}); }
}
function verifyGoogleToken(token) {
  if (!token) throw new Error("Log opnieuw in met Google");
  const response = UrlFetchApp.fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(token), {muteHttpExceptions:true});
  const data = JSON.parse(response.getContentText());
  if (response.getResponseCode() !== 200 || data.aud !== GOOGLE_CLIENT_ID || data.email_verified !== "true") throw new Error("Google-login kon niet worden geverifieerd");
  return {email:data.email,name:data.name || data.email};
}
function json(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}