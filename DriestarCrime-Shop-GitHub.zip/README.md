# DriestarCrime Shop — GitHub Pages

Een responsive, donker gaming-marketplace ontwerp met Home, Aanbod/Verkopen, Google-login en Mijn account.

## 1. Online zetten met GitHub Pages
1. Maak op https://github.com een **Public** repository, bijvoorbeeld `driestarcrime-shop`.
2. Upload alle bestanden en mappen uit deze projectmap. Zorg dat `index.html` direct in de hoofdmap staat (niet in een extra submap).
3. Open **Settings → Pages**.
4. Kies **Deploy from a branch**, branch `main`, map `/ (root)` en klik **Save**.
5. Na publicatie staat de website op `https://JOUW-GITHUB-NAAM.github.io/driestarcrime-shop/`.

## 2. Wat werkt direct?
- Alle pagina's en navigatie werken.
- De website is mobielvriendelijk.
- Zoeken en filteren in advertenties werkt.
- Zonder serverconfiguratie kun je lokaal in je browser demo-advertenties bekijken en nieuwe advertenties testen. Die testadvertenties worden alleen in die browser opgeslagen; bezoekers delen ze dus niet automatisch.

## 3. Google-login instellen
1. Open https://console.cloud.google.com/ en maak/selecteer een Google Cloud-project.
2. Configureer het OAuth-toestemmingsscherm (External; vul de gevraagde appgegevens in).
3. Maak een OAuth-client-ID van type **Web application**.
4. Voeg je GitHub Pages-domein toe bij **Authorized JavaScript origins**, bijvoorbeeld `https://JOUW-GITHUB-NAAM.github.io` (geen pad).
5. Kopieer de Client ID naar `assets/config.js` bij `GOOGLE_CLIENT_ID`.

## 4. Advertenties tussen bezoekers delen (optionele Apps Script backend)
Voor gedeelde advertenties is een server nodig. Dit project bevat een Apps Script voorbeeld in `apps-script/Code.gs`.
1. Maak een Google Sheet en kopieer het spreadsheet-ID uit de URL.
2. Open https://script.google.com/ en maak een project. Plak `Code.gs`.
3. Vul `SPREADSHEET_ID` en `GOOGLE_CLIENT_ID` bovenaan in.
4. Voer `setup` één keer uit en geef toestemming. De functie maakt de tab `Ads`.
5. Deploy → New deployment → type **Web app**. Execute as **Me**. Who has access: **Anyone**. Kopieer de Web app URL naar `API_URL` in `assets/config.js`.
6. Gebruik dezelfde OAuth Client ID in de Apps Script-code en `assets/config.js`.

Let op: dit is een basisimplementatie. Controleer advertenties voordat je ze publiceert. Deel geen wachtwoorden, privégegevens of gevoelige informatie. Google-login identificeert de gebruiker; het is geen betaal- of escrow-systeem. Regel betalingen en verzending zelf veilig.

## Belangrijke GitHub Pages beperking
GitHub Pages host alleen statische bestanden. Het voert geen PHP of eigen database uit. Voor gedeelde opslag gebruiken we daarom optioneel Google Apps Script + Sheets. De demo-modus is alleen voor testen in één browser.
