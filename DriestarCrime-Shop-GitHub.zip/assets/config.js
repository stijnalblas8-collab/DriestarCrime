// Vul deze instellingen pas in nadat je Google-login en Apps Script hebt ingesteld.
window.DCS_CONFIG = {
  GOOGLE_CLIENT_ID: "VUL_HIER_JE_GOOGLE_OAUTH_CLIENT_ID_IN",
  API_URL: "VUL_HIER_JE_APPS_SCRIPT_WEB_APP_URL_IN"
};